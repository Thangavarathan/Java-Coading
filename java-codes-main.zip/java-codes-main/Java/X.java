import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

                        double value = scanner.nextDouble();

                System.out.printf("%e%n", value);

        scanner.close();
    }
}
