//to find the palindrome of a string within the substring


import java.util.Scanner;
class Palindromicsubstring{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String s=("thequickbrownfoxxofnworbquickthe");
		 
		