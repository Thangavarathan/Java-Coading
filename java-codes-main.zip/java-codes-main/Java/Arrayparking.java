import java.util.Scanner;
class Arrayparking{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int s=20;
		int arr[]=new int[20];
		System.out.println("Enter your choice\n1.Entry 2.Exit");
		int c=sc.nextInt();
		if(c==1){
			System.out.println("Enter your vehicle number: ");
			int v=sc.nextInt();
		}

	}
}

		
		